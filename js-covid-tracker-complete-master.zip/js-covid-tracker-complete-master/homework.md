

# June 20 Homework

- Add a pie chart to the Covid Tracker at the bottom of the site
- Make the card clickable so the map reflects the data selected

# June 27 Homework

- Make sure you are updated the functinoality of the app
- Add a hover state to the Tabs
- Add an active state to the Tabs
- Change the line graph that will show call cases, recovered, and deaths
- Add a table on the side panel show the numbers of the countries

# July 8 Homework

- Add the Active State  for the Tabs based on the Mockup
- Modify the Map to be in a Container as in the Mockup
- Sort the countries Data
- Make sure you are updated with the app
