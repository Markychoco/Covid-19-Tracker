# July 8 Plan Of Action

- Modify COVID Title DONE
- Modify the colors of the application TO DO
- Modify Side Panel DONE
- Add Side Panel to Load Data by Country DONE
- Add the Active State on Click TO DO
- Move the Graph into the Sidebar DONE
- Load real numbers from CORONA API DONE

