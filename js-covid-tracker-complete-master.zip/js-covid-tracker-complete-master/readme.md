# COVID Tracker

- Modify wireframe DONE
- Get Country data
- Show country data on the map
- Show country data in a table 